#!/usr/bin/env python3
# -*- coding: utf-8 -*-

'''
Override configurations.
'''


configs = {
    'db': {
        'user': 'root',
        'password':'go2live'
    }
}